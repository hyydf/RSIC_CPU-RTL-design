ASIC课程实验，八位CPU的RTL设计的源码。
cells_lib为各个module。linux下用批处理文件run.f运行，运行结果在运行结果文件夹里。
CPU测试案例为CPU_test1.dat~CPU_test13.dat，
CPU_test4.dat和CPU_test5.dat为自己写的测试案例，分别为乘法器和阶乘器。
作者ID：会咬鸢的风(CSDN/github)，欢迎学习交流。